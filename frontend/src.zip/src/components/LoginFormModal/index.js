import LoginFormPage from './LoginFormModal';

export default LoginFormPage;

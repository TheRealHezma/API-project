import SignupFormPage from './SignupFormModal';

export default SignupFormPage;
